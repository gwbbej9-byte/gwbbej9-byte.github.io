cert-lens ? X.509 viewer
Double-click cert-lens.exe
Open certificate -> example.pem (in this zip) or drop a PEM/DER on the window.
Windows x64. No extra runtime.
