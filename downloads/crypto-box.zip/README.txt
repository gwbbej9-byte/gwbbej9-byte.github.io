crypto-box ? AES-256-GCM file encryptor
Double-click crypto-box.exe
Type a password, Encrypt file / Decrypt file.
Windows x64. No extra runtime.
