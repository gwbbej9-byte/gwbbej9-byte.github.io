harborlm ? local GGUF chat TUI
Offline demo (no weights):
  harborlm.exe chat --demo
Live needs llama.cpp server; see the GitHub README.
Windows x64 console. No Python install needed.
