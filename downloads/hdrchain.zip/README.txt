hdrchain ? C++20 SHA-256d header chain
Run:
  hdrchain.exe genesis chain.hdrc coinbase
  hdrchain.exe append chain.hdrc pay-alice
  hdrchain.exe verify chain.hdrc
  hdrchain.exe show chain.hdrc
Windows x64. No extra runtime.
