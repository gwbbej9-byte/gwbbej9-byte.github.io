logship ? concurrent log tail
  logship.exe tail app.log api.log --listen :8080
Then open http://127.0.0.1:8080/healthz
Windows x64. No extra runtime.
