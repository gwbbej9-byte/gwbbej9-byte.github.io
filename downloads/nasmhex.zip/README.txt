nasmhex ? x86-64 Linux hexdump, no libc
This zip is a Linux ELF, not a Windows exe.
WSL / Linux:
  chmod +x nasmhex
  ./nasmhex hello.bin
Windows: use WSL2 or Docker.
