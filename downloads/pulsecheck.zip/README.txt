pulsecheck ? HTTP/TCP health TUI
  pulsecheck.exe demo
  pulsecheck.exe demo --once
Windows x64 console. No Python install needed.
