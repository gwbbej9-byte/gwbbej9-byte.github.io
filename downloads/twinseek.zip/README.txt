twinseek ? SHA-256 duplicate finder
  twinseek.exe scan .
  twinseek.exe scan C:\path
d marks only. Never deletes.
Windows x64. No extra runtime.
