winpulse ? process monitor
Needs .NET 8 Desktop Runtime:
  https://dotnet.microsoft.com/download/dotnet/8.0
Then double-click WinPulse.exe
Windows x64.
